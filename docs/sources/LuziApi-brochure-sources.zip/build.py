#!/usr/bin/env python3
"""Génère les PDF de la brochure LuziApi depuis les sources HTML/CSS.

    python3 build.py

Produit LuziApi-brochure.pdf (A4 paysage) et LuziApi-brochure-print.pdf
(fond perdu 3 mm + traits de coupe).

Dépendances : playwright (node), qrcode (python).
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent
CHROME = "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"

MARKS = """<svg class="marks" viewBox="0 0 313 226" width="313mm" height="226mm" xmlns="http://www.w3.org/2000/svg">
      <g stroke="#000" stroke-width="0.25" shape-rendering="crispEdges">
        <!-- traits de coupe verticaux (coupe a x = 8 et x = 305) -->
        <line x1="8" y1="0" x2="8" y2="4"/><line x1="8" y1="222" x2="8" y2="226"/>
        <line x1="305" y1="0" x2="305" y2="4"/><line x1="305" y1="222" x2="305" y2="226"/>
        <!-- traits de coupe horizontaux (coupe a y = 8 et y = 218) -->
        <line x1="0" y1="8" x2="4" y2="8"/><line x1="309" y1="8" x2="313" y2="8"/>
        <line x1="0" y1="218" x2="4" y2="218"/><line x1="309" y1="218" x2="313" y2="218"/>
        <!-- reperes de pliage (plis a 99 et 198 mm du bord de coupe) -->
        <line x1="107" y1="1.5" x2="107" y2="4" stroke-dasharray="1 1"/>
        <line x1="107" y1="222" x2="107" y2="224.5" stroke-dasharray="1 1"/>
        <line x1="206" y1="1.5" x2="206" y2="4" stroke-dasharray="1 1"/>
        <line x1="206" y1="222" x2="206" y2="224.5" stroke-dasharray="1 1"/>
      </g>
    </svg>"""

RENDER_JS = """
const {{ chromium }} = require('playwright');
(async () => {{
  const b = await chromium.launch({{executablePath: {chrome!r}}});
  const p = await b.newPage();
  await p.goto({url!r}, {{ waitUntil: 'networkidle' }});
  await p.evaluate(() => document.fonts.ready);
  await p.waitForTimeout(600);
  await p.pdf({{ path: {out!r}, width: {w!r}, height: {h!r}, printBackground: true,
                margin: {{top:'0',right:'0',bottom:'0',left:'0'}} }});
  await b.close();
}})();
"""


def make_qr():
    """Regénère le QR code vers la boutique."""
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M

    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_M, box_size=20, border=2)
    qr.add_data("https://luziapi.fr")
    qr.make(fit=True)
    img = qr.make_image(fill_color="#2B1D10", back_color="#FFFFFF").convert("RGB")
    img.save(HERE / "assets" / "qr-luziapi.png")


def prepare_cover():
    """La photo de couverture est utilisee telle quelle, sans retouche.

    assets/cover-rucher-src.jpg est l'original ; il est simplement recopie.
    Deposer un original haute resolution sous ce nom et relancer le build.
    """
    import shutil

    src = HERE / "assets" / "cover-rucher-src.jpg"
    if src.exists():
        shutil.copy(src, HERE / "assets" / "cover-rucher.jpg")


def make_print_html():
    """Dérive la version imprimeur depuis brochure.html."""
    html = (HERE / "brochure.html").read_text(encoding="utf-8")
    html = html.replace(
        '<link rel="stylesheet" href="style.css">',
        '<link rel="stylesheet" href="style.css">\n<link rel="stylesheet" href="print.css">',
    )
    html = html.replace(
        '<section class="sheet">', '<div class="pagewrap">\n    ' + MARKS + '\n    <section class="sheet">'
    )
    html = html.replace("</section>", "</section>\n  </div>")
    (HERE / "brochure-print.html").write_text(html, encoding="utf-8")


def render(src, out, w, h):
    js = HERE / "_render.js"
    js.write_text(
        RENDER_JS.format(chrome=CHROME, url=f"file://{HERE / src}", out=str(HERE / out), w=w, h=h)
    )
    subprocess.run(["node", str(js)], check=True, cwd=HERE)
    js.unlink()
    print(f"  → {out}")


if __name__ == "__main__":
    if not Path(CHROME).exists():
        sys.exit(f"Chromium introuvable : {CHROME}\nAdapter la constante CHROME en tête de ce fichier.")
    make_qr()
    prepare_cover()
    make_print_html()
    print("Rendu des PDF…")
    render("brochure.html", "LuziApi-brochure.pdf", "297mm", "210mm")
    render("brochure-print.html", "LuziApi-brochure-print.pdf", "313mm", "226mm")
    print("Terminé.")
