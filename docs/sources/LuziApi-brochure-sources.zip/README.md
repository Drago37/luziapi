# Brochure LuziApi — 3 volets A4 paysage

Sources de la brochure imprimée. Le PDF est généré depuis du HTML/CSS rendu par
Chromium : pas de logiciel de PAO, tout se modifie dans `brochure.html` + `style.css`.

## Fichiers

| Fichier | Rôle |
|---|---|
| `brochure.html` | Contenu et structure des 6 volets |
| `style.css` | Charte graphique et échelle typographique |
| `print.css` | Surcouche fond perdu + traits de coupe (version imprimeur) |
| `brochure-print.html` | Généré depuis `brochure.html` par `build.py` — ne pas éditer à la main |
| `assets/` | Photos, QR code |
| `fonts/` | Fraunces (titres) et Hanken Grotesk (textes) |
| `build.py` | Génère `brochure-print.html` puis les deux PDF |

## Générer les PDF

```bash
python3 build.py
```

Produit :

- `LuziApi-brochure.pdf` — 297 × 210 mm (A4 paysage), pour le web et l'impression maison
- `LuziApi-brochure-print.pdf` — 313 × 226 mm, format fini 297 × 210 mm
  + 3 mm de fond perdu + traits de coupe et repères de pliage

## Échelle typographique

Refonte d'août 2026 : tous les corps de texte ont été remontés, le volet
« Un essaim d'abeilles chez vous ? » était illisible à 7,6 pt.
Aucun texte n'a été raccourci — la place vient uniquement de la mise en page.

| Rôle | Avant | Après |
|---|---|---|
| Corps de texte | 6,9 – 7,6 pt | **9,5 pt** |
| Descriptions, sous-textes | 5,6 – 6,5 pt | **8,5 pt** |
| Sur-titres (« OÙ NOUS TROUVER ») | 5,0 – 5,4 pt | **7 pt** |
| Mentions légales | 5,0 pt | **7,5 pt** |
| Légendes de saison, sous-liens | 5,2 – 5,6 pt | **6,5 – 6,8 pt** |
| Crédits photo | 4,0 pt | **5,5 pt** |
| Titres de volet | 18 – 19 pt | 19 pt (inchangé) |

Aucun texte n'a été supprimé ni réécrit : la place a été reprise sur les marges,
les interlignes et la hauteur des photos. Les paragraphes courts utilisent
`text-wrap: balance` pour éviter les lignes orphelines sans toucher au contenu.

Les tailles se pilotent depuis les variables en haut de `style.css` :

```css
--fs-eyebrow:7pt;   /* sur-titres */
--fs-title:19pt;    /* titres de volet */
--fs-body:9.5pt;    /* corps */
--fs-body-sm:8.5pt; /* descriptions */
--fs-micro:7.5pt;   /* mentions */
--fs-credit:5.5pt;  /* crédits photo */
```

## Mise en page

- Page : 297 × 210 mm, 3 volets de 99 mm, plis à 99 et 198 mm
- Marges intérieures : 8,5 mm horizontal, 9 mm vertical
- Photos à bord perdu (volets 4 et 5) : 55 mm, via `--h-top-photo`
- Page 1 (extérieur) : couverture · Où nous trouver · Un essaim chez vous ?
- Page 2 (intérieur) : L'apiculteur · Du rucher au pot · Nos miels

## Charte

| | |
|---|---|
| Crème (fond) | `#FFFAF0` |
| Crème carte | `#FCF5E3` |
| Filet crème | `#E6D2A8` |
| Brun texte | `#2B1D10` |
| Brun adouci | `#3A2917` |
| Brun profond | `#201409` |
| Or | `#E8A317` |
| Or foncé | `#C98A16` |
| Dégradé miel | `#F8E0A6` → `#EAB84A` |

Polices : **Fraunces** (titres, prix, URL) et **Hanken Grotesk** (courants),
embarquées en local — aucun appel à Google Fonts au rendu.

## Points de vigilance

- **Résolution des photos.** `cover-rucher.jpg` (140 dpi au format final) et
  `cadre-miel.jpg` (env. 200 dpi) sont sous les 300 dpi recommandés. Elles ont été
  récupérées depuis l'ancien PDF. Les originaux 6000 × 4000 de Thomas Bourdilleau
  existent : les déposer dans `assets/` et relancer `build.py` améliorera nettement
  le rendu imprimé. Les trois autres photos sont à 296 – 350 dpi.
- **QR code** : pointe vers `https://luziapi.fr`, regénérable via `build.py`.
- Le PDF est en **RVB**. Si l'imprimeur exige du CMJN, faire la conversion
  en sortie (Ghostscript ou côté imprimeur).
