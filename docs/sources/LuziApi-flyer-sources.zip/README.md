# LuziApi — flyer A5

Sources du flyer recto/verso, alignées sur celles de la brochure.

## Générer les PDF

    python3 build.py

Produit `LuziApi-flyer.pdf` (148 × 210 mm, à l'écran) et
`LuziApi-flyer-print.pdf` (162 × 224 mm : fond perdu 3 mm + traits de coupe).

Dépendances : `node` + `playwright`, `python3` + `qrcode`, `Pillow`.
Le chemin de Chromium est en tête de `build.py` (constante `CHROME`).

## Choix de fabrication

- **Fonte** : Fraunces en version *variable*, axes `opsz` / `SOFT 0` / `WONK 1`.
  Les instances statiques ne contiennent que le dessin « soft », trapu :
  ne pas les substituer.
- **Trame d'alvéoles** : le motif SVG est un pavage continu (maille 60 × 103,923,
  5 hexagones dont les moitiés de bord se complètent d'une tuile à l'autre).
- **Teinte de l'en-tête** : calque brun uni en `mix-blend-mode: multiply`,
  isolé par `isolation: isolate` sur `.hero__img` pour que le texte reste
  vectoriel dans le PDF. Couleur réglable via `--tint`.
- **Échelle typographique** : corps 9,5 pt, rien en dessous de 6 pt.
- Les blocs miel et promo sont en **aplat uni** (`--honey`), sans dégradé.

## Photos

`assets/flyer-header.jpg` est à ~214 dpi au format d'emploi, en dessous des
300 dpi habituels en offset. Remplacer par l'original haute résolution avant
tirage, en conservant le même nom.
