#!/usr/bin/env python3
"""Génère les PDF du flyer LuziApi A5 depuis les sources HTML/CSS.

    python3 build.py

Produit LuziApi-flyer.pdf (A5 recto/verso) et LuziApi-flyer-print.pdf
(fond perdu 3 mm + traits de coupe).
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent
CHROME = "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"

MARKS = """<svg class="marks" viewBox="0 0 162 224" width="162mm" height="224mm" xmlns="http://www.w3.org/2000/svg">
      <g stroke="#000" stroke-width="0.25" shape-rendering="crispEdges">
        <line x1="8" y1="0" x2="8" y2="4"/><line x1="8" y1="220" x2="8" y2="224"/>
        <line x1="154" y1="0" x2="154" y2="4"/><line x1="154" y1="220" x2="154" y2="224"/>
        <line x1="0" y1="8" x2="4" y2="8"/><line x1="158" y1="8" x2="162" y2="8"/>
        <line x1="0" y1="216" x2="4" y2="216"/><line x1="158" y1="216" x2="162" y2="216"/>
      </g>
    </svg>"""

RENDER_JS = """
const {{ chromium }} = require('playwright');
(async () => {{
  const b = await chromium.launch({{executablePath: {chrome!r}}});
  const p = await b.newPage();
  await p.goto({url!r}, {{ waitUntil: 'networkidle' }});
  await p.evaluate(() => document.fonts.ready);
  await p.waitForTimeout(600);
  await p.pdf({{ path: {out!r}, width: {w!r}, height: {h!r}, printBackground: true,
                margin: {{top:'0',right:'0',bottom:'0',left:'0'}} }});
  await b.close();
}})();
"""


def make_qr():
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M

    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_M, box_size=20, border=2)
    qr.add_data("https://luziapi.fr")
    qr.make(fit=True)
    img = qr.make_image(fill_color="#2B1D10", back_color="#FFFFFF").convert("RGB")
    img.save(HERE / "assets" / "qr-luziapi.png")


def make_print_html():
    html = (HERE / "flyer.html").read_text(encoding="utf-8")
    html = html.replace(
        '<link rel="stylesheet" href="style.css">',
        '<link rel="stylesheet" href="style.css">\n<link rel="stylesheet" href="print.css">',
    )
    html = html.replace('<section class="sheet">', '<div class="pagewrap">\n    ' + MARKS + '\n    <section class="sheet">')
    html = html.replace("</section>", "</section>\n  </div>")
    (HERE / "flyer-print.html").write_text(html, encoding="utf-8")


def render(src, out, w, h):
    js = HERE / "_render.js"
    js.write_text(RENDER_JS.format(chrome=CHROME, url=f"file://{HERE / src}", out=str(HERE / out), w=w, h=h))
    subprocess.run(["node", str(js)], check=True, cwd=HERE)
    js.unlink()
    print(f"  → {out}")


if __name__ == "__main__":
    if not Path(CHROME).exists():
        sys.exit(f"Chromium introuvable : {CHROME}")
    make_qr()
    make_print_html()
    print("Rendu des PDF…")
    render("flyer.html", "LuziApi-flyer.pdf", "148mm", "210mm")
    render("flyer-print.html", "LuziApi-flyer-print.pdf", "162mm", "224mm")
    print("Terminé.")
