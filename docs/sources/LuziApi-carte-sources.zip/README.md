# LuziApi — carte de visite

Sources de la carte 85 × 55 mm recto/verso, alignées sur la brochure et le flyer.

## Générer les PDF

    python3 build.py

Produit `LuziApi-carte.pdf` (85 × 55 mm, page 1 = recto, page 2 = verso) et
`LuziApi-carte-print.pdf` (101 × 71 mm : fond perdu 3 mm + traits de coupe).

Dépendances : `node` + `playwright`, `python3` + `qrcode`, `Pillow`.
Le chemin de Chromium est en tête de `build.py` (constante `CHROME`).

## Ce qui a été corrigé

- **Trame d'alvéoles** : le motif d'origine ne se raccordait pas d'une tuile à
  l'autre. Remplacé par un pavage continu (maille 60 × 103,923, 5 hexagones
  dont les moitiés de bord se complètent).
- **Plancher typographique à 6 pt** : « Apiculture artisanale » passe de 5,4 à
  6,5 pt, « Apiculteur » de 5,2 à 6,5 pt, les coordonnées de 6,6 à 7 pt.
- **Version imprimeur** : elle n'existait pas. Le recto est un aplat plein bord,
  il lui faut impérativement 3 mm de débord sous peine de liseré blanc à la coupe.

## Points de fabrication

- **Fonte** : Fraunces en version *variable*, axes `opsz` / `SOFT 0` / `WONK 1`.
  Les instances statiques ne contiennent que le dessin « soft », trapu :
  ne pas les substituer.
- Les logos Facebook et Instagram sont en RVB : en quadrichromie le bleu
  s'assombrit et le dégradé Instagram perd de la saturation dans les violets.
